public class Transitive {
    public static void main(String[] args) throws Exception {
        /*
         * If you can come up with a set of primitive types and values
         * that causes this program to print "true true false", then
         * you have proven that the == operator is not transitive.
         */
        <typeX> x = <valueX>;
        <typeY> y = <valueY>;
        <typeZ> z = <valueZ>;

        System.out.print ((x == y) + " ");
        System.out.print ((y == z) + " ");
        System.out.println(x == z);
    }
}
