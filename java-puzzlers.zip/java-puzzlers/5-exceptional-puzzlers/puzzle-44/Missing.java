class Missing {
    Missing() { }
}
