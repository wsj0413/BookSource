public class Thrower {
    public static void main(String[] args) {
        sneakyThrow(new Exception("This is a checked exception"));
    }

    /*
     * Provide a body for this method to make it throw the specified exception.
     * You must not use any deprecated methods.
     */
    public static void sneakyThrow(Throwable t) {

    }
}
