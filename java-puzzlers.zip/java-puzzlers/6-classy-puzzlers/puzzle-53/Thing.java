// This is meant to represent a library class. You must not modify it.
public class Thing {
    public Thing(int i) {
    }
}
