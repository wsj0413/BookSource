public class Type2 {
    public static void main(String[] args) {
        System.out.println(new Type2() instanceof String);
    }
}
