public class Type3 {
    public static void main(String args[]) {
        Type3 t2 = (Type3) new Object();
    }
}
